//
//  ViewController.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

//MARK: Declare Global Variable
var navigationControllerCustm = UINavigationController()

class expandableViewController: UIViewController {

    //MARK: OutLet
    @IBOutlet weak var multipleCellTabelView: UITableView!
    
    //MARK:  View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.title = "Offering"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        registerCell()
        setNavigationBar()
        navigationControllerCustm = self.navigationController!
    }
    
}

extension expandableViewController: UITableViewDelegate, UITableViewDataSource{
    
    // MARK: Cell Register
    private func registerCell(){
        multipleCellTabelView.delegate = self
        multipleCellTabelView.dataSource = self
        multipleCellTabelView.register(UINib(nibName: "HeaderCell", bundle: nil), forCellReuseIdentifier: "HeaderCell")
        multipleCellTabelView.register(UINib(nibName: "ExpandableTableCell", bundle: nil), forCellReuseIdentifier: "ExpandableTableCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "HeaderCell", for: indexPath) as? HeaderCell else{ return .init()}
            return cell
        }else{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "ExpandableTableCell", for: indexPath) as? ExpandableTableCell else{ return .init()}
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            return 300
        }
        else{
            return 800
        }
    }
}



//MARK: Extension For Set Navigation Item
extension expandableViewController{
    
    func setNavigationBar() {
        self.navigationController?.navigationBar.isHidden = false
        navigationController?.setNavigationBarHidden(false, animated: false)
        
        let btnUserImage = UIButton(type: .custom)
        btnUserImage.setImage(UIImage(named: "home1"), for: .normal)
        btnUserImage.frame = CGRect(x: 0, y: 4, width: 25, height: 25)
        btnUserImage.showsTouchWhenHighlighted = false
        btnUserImage.isUserInteractionEnabled = false
        let rightBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 36, height: 36))
        rightBarButtonItems.addSubview(btnUserImage)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: rightBarButtonItems)
    }
}
