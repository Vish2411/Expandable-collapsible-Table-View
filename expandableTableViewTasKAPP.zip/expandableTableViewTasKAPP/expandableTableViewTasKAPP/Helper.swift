//
//  Helper.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import Foundation
import UIKit

class ItemList {
    var header: String
    var items: [ModelData]
    var exponds: Bool

    
    init(header: String, items:[ModelData], exponds: Bool = false) {
        self.header = header
        self.items = items
        self.exponds = exponds
    }  
}

struct ModelData{
    var labelName1:String?
    var imageName:String?
    var labelName2:String?
    var labelName3:String?
    var documentUrl:String?
}

