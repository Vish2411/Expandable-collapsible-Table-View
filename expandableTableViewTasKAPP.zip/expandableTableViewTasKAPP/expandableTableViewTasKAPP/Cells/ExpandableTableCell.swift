//
//  ExpandableTableCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

class ExpandableTableCell: UITableViewCell {

    //MARK: OutLet
    @IBOutlet weak var expandTableView: UITableView!
    
    //Declare Data
    var productData: [ItemList] = [
        ItemList(header: "Purpose Of The Offering", items: [ModelData(labelName1: "Ancient Greek playwright Sophocles wrote, “Wisdom outweighs any wealth.” While this statement certainly rings true, it’s also true that wisdom can play a major role in achieving wealth—particularly when it comes to effectively managing your finances and credit.So, in the spirit of gleaning useful advice from some of the finest, shrewdest minds throughout history, here are 10 pertinent quotations to consider when dealing with your money and credit")]),
        ItemList(header: "Product And Service", items: [ModelData(labelName1: "bbsdfhsr nfdefg hsdswh hdhss hsgdsbdsjdmsjdsuwd njshgdsdjksbfs ksgsbd")]),
        ItemList(header: "Officer Of The Company", items: [ModelData(labelName1: "Hitesh Deshmukh", imageName: "star", labelName2: "CEO")]),
        ItemList(header: "Offering Information", items: [
            ModelData(labelName1: "Co-issuer:", labelName2: "Candies Paradise"),
            ModelData(labelName1: "Target Offering Amount", labelName2: "$0"),
            ModelData(labelName1: "Maxximum Offering Amount", labelName2: "$0"),
            ModelData(labelName1: "Security Type:", labelName2: "Convertible Zero-Coupon Bond"),
            ModelData(labelName1: "This Convertible Zero-Coupon bonds will convert into gummeis class of equity shares.", labelName2: ""),
            ModelData(labelName1: "Valuation Cap:", labelName2: "$ 10,000,000"),
            ModelData(labelName1: "Conversion Discount", labelName2: "5%"),
            ModelData(labelName1: "Maturity Date:", labelName2: "--"),
            ModelData(labelName1: "Rolling Close", labelName2: "Yes"),
            ModelData(labelName1: "To verify a smart contract, copy the address and paste it in block chain explore it https://etherscan.io.", labelName2: "Adress of the pledge receipt contract", labelName3: "0x253...674573893l"),
            ModelData(labelName1: "Maxximum Offering Amount", labelName2: "$10"),
            ModelData(labelName1: "managing your finances and credit.So, in the spirit of gleaning useful advice from some of the finest, shrewdest minds throughout history",labelName2: ""),
            ModelData(labelName1: "To verify a smart contract, copy the address and paste it in block chain explore it https://etherscan.io.", labelName2: "Adress of the pledge receipt contract", labelName3: "0x253...674573893l"),
            ModelData(labelName1: "Link to Offering document", labelName2: "Offering Document")
            
        ]),
        
        ItemList(header: "Invester Perks", items: [ModelData(labelName1: "Image result for Investor Perks Investor is a perk that becomes available when the Dragonborn reaches 70 in the Speech skill. Using this perk allows the Dragonborn to invest 500 in certain shops and merchants. The effect is that the shops in which the Dragonborn has invested will have 500")]),
        ItemList(header: "Risk Factor", items: [ModelData(labelName1: "Something that increases the chance of developing a disease. Some examples of risk factors for cancer are age, a family history of certain cancers, use of tobacco products, being exposed to radiation or certain chemicals, infection with certain viruses or bacteria, and certain genetic changes.")]),
        ItemList(header: "Offering Document", items: [
            ModelData(labelName1: "Offering Memorandum",documentUrl: "https://s29.q4cdn.com/816090369/files/doc_downloads/test.pdf"),
            ModelData(labelName1: "Debt Agreement",documentUrl: "https://www.africau.edu/images/default/sample.pdf")
        ])
        
//
    ]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        expandTableView.delegate = self
        expandTableView.dataSource = self
        registerCell()
        
//        expandTableView.layoutIfNeeded()
//        tableViewHeight  = expandTableView.contentSize.height
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}

extension ExpandableTableCell{
    
    @objc func headerViewTapped(tapped:UITapGestureRecognizer){
        print(tapped.view?.tag)
        if productData[tapped.view!.tag].exponds == true{
            productData[tapped.view!.tag].exponds = false
        }else{
            productData[tapped.view!.tag].exponds = true
        }
        if let imageView = tapped.view?.subviews[1] as? UIImageView{
            if imageView.isKind(of: UIImageView.self){
                if productData[tapped.view!.tag].exponds{
                    imageView.isHidden = true
                }else{
                    imageView.image = UIImage(named: "expand")
                }
            }
        }
        
        expandTableView.reloadData()
    }
}

//MARK: - TableView Delegate & Data source Method
extension ExpandableTableCell : UITableViewDelegate, UITableViewDataSource{
    
    private func registerCell(){
        expandTableView.register(UINib(nibName: "singleLabelCell", bundle: nil), forCellReuseIdentifier: "singleLabelCell")
        expandTableView.register(UINib(nibName: "imageCell", bundle: nil), forCellReuseIdentifier: "imageCell")
        expandTableView.register(UINib(nibName: "twoLabelCell", bundle: nil), forCellReuseIdentifier: "twoLabelCell")
        expandTableView.register(UINib(nibName: "documentCell", bundle: nil), forCellReuseIdentifier: "documentCell")
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: self.expandTableView.frame.width, height: 40))
        let headerHeading = UILabel(frame: CGRect(x: 10, y: 5, width: headerView.frame.width - 10, height: headerView.frame.height - 5))
        let imageView = UIImageView(frame: CGRect(x: self.expandTableView.frame.width - 30, y: 10, width: 20, height: 20))
        headerHeading.font = UIFont.boldSystemFont(ofSize: 16)
        
        if productData[section].exponds{
            imageView.image = UIImage(named: "expand")
            headerView.backgroundColor = UIColor.init(cgColor: CGColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1.0))
            headerHeading.textColor = .white
            
        }else{
            
            imageView.isHidden = true
            headerView.backgroundColor = .systemBackground
            headerHeading.textColor = .black
            headerView.layer.borderColor = UIColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1).cgColor
            headerView.layer.borderWidth = 1
            headerView.layoutIfNeeded()
        }
        
        let tapGuesture = UITapGestureRecognizer(target: self, action: #selector(headerViewTapped))
        tapGuesture.numberOfTapsRequired = 1
        headerView.addGestureRecognizer(tapGuesture)
        headerView.tag = section
        headerHeading.text = productData[section].header
        headerView.addSubview(headerHeading)
        headerView.addSubview(imageView)
        self.expandTableView.addSubview(headerView)
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return productData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let itms = productData[section]
        return !itms.exponds ? 0 : itms.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else {return .init()}
            cell.singleLabelText.text = productData[indexPath.section].items[indexPath.row].labelName1
            return cell
        }else if indexPath.section == 1 {
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else {return .init()}
            cell.singleLabelText.text = productData[indexPath.section].items[indexPath.row].labelName1
            return cell
        }else if indexPath.section == 2{
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "imageCell", for: indexPath) as? imageCell else {return .init()}
            cell.setData(productData[indexPath.section].items[indexPath.row])
            return cell
        }else if indexPath.section == 3{
            
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "twoLabelCell", for: indexPath) as? twoLabelCell else {return .init()}
            cell.setData(productData[indexPath.section].items[indexPath.row])
            return cell
            
        }else if indexPath.section == 4 || indexPath.section == 5{
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else {return .init()}
            cell.singleLabelText.text = productData[indexPath.section].items[indexPath.row].labelName1
            return cell
        }else{
            guard let cell = self.expandTableView.dequeueReusableCell(withIdentifier: "documentCell", for: indexPath) as? documentCell else {return .init()}
            cell.setData(productData[indexPath.section].items[indexPath.row])
            cell.buttonViewD.tag = (indexPath.section * 1000) + indexPath.row
            cell.buttonViewD.addTarget(self, action: #selector(documentButtonTappedAction), for: .touchUpInside)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

//MARK: - View document button tapped
extension ExpandableTableCell{
    @objc func documentButtonTappedAction(_ sender:UIButton){
        
        var row = sender.tag % 1000
        var section = sender.tag / 1000
        
        guard let pdfVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "pdfLoadViewController") as? pdfLoadViewController else{
            return
        }
        let selectedIndex = IndexPath(row: row, section: section)
        pdfVC.pdfUrl = productData[selectedIndex.section].items[selectedIndex.row].documentUrl
        
        navigationControllerCustm.pushViewController(pdfVC, animated: true)
    }
}
