//
//  twoLabelCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit



class twoLabelCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var labelName1: UILabel!
    @IBOutlet weak var labelName2: UILabel!
    @IBOutlet weak var label2View: UIView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var labelName3: UILabel!
    @IBOutlet weak var label3view: UIView!
    
    @IBOutlet weak var lineView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        backviewBorderSet()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(_ data:ModelData){
        
        labelName1.text = data.labelName1
        
        
        if data.labelName2 == "" || data.labelName2 == nil{
            label2View.isHidden = true
            lineView.isHidden = true
        }else{
            
            label2View.isHidden = false
            lineView.isHidden = false
            labelName2.text = data.labelName2
            
            if data.labelName2 == "Offering Document"{
                labelName2.textColor = UIColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1)
            }else{
                labelName2.textColor = .black
            }
        }
        
        if data.labelName3 ==  nil || data.labelName3 == ""{
            label3view.isHidden = true
        }else{
            label3view.isHidden = false
            labelName3.text = data.labelName3
            lineView.isHidden = false
        }
        
        
    }
    
    func backviewBorderSet(){
        
        self.backView.layer.borderWidth = 1
        self.backView.layer.borderColor = UIColor.init(cgColor: CGColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.6)).cgColor
        self.backView.layer.cornerRadius = 8
        self.backView.layer.layoutIfNeeded()
    }
}
