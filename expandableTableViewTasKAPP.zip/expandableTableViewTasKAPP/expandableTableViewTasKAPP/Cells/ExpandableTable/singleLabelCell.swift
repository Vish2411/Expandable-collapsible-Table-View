//
//  ExpondCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

class singleLabelCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var singleLabelText: UILabel!
    @IBOutlet weak var labelView: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        setBorder()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setBorder(){
        self.labelView.layer.borderColor = UIColor.red.cgColor
        self.labelView.layer.borderWidth = 10
        self.labelView.backgroundColor = .green
        self.labelView.layoutIfNeeded()
    }
}
