//
//  documentCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 19/09/22.
//

import UIKit

class documentCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var buttonViewD: UIButton!
    @IBOutlet weak var DocumentName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(_ data:ModelData){
        DocumentName.text = data.labelName1
    }
    
}
