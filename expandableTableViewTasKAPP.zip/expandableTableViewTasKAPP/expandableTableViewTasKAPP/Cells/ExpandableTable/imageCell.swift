//
//  imageCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

class imageCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var labelName1: UILabel!
    @IBOutlet weak var ImageName: UIImageView!
    @IBOutlet weak var labelName2: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(_ data:ModelData){
        labelName1.text = data.labelName1
        ImageName.image = UIImage(named: data.imageName!)
        labelName2.text = data.labelName2
    }
    
}
