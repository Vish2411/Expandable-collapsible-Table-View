//
//  pdfLoadViewController.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 19/09/22.
//

import UIKit
import WebKit

class pdfLoadViewController: UIViewController {

    //MARK: OutLet
    let webView = WKWebView()
    var pdfUrl:String?
    
    //MARK:  View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
         
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.SetBackButtonNavigation()
        self.loadPdf()
        self.setupViews()
    }
    
    func SetBackButtonNavigation(){
        title = "View Document"
        navigationController?.navigationBar.backgroundColor = UIColor.init(cgColor: CGColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1.0))
        
        self.navigationController?.navigationBar.isHidden = false
        navigationController?.setNavigationBarHidden(false, animated: false)
        let backBtn = UIButton(type: .custom) //arrow.left
        backBtn.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        backBtn.frame = CGRect(x: 0, y: 0, width: 36, height: 36)
        backBtn.showsTouchWhenHighlighted = true
        backBtn.isUserInteractionEnabled = true
        backBtn.addTarget(self, action: #selector(self.btnback_Click_Action), for: .touchUpInside)
        backBtn.tintColor = .black
        let leftBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 36, height: 36))
        leftBarButtonItems.addSubview(backBtn)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftBarButtonItems)
    }

    @objc func btnback_Click_Action(_ sender:UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    func loadPdf() {
        if pdfUrl != nil{
            if let pdfUrl = URL(string: pdfUrl!) {
                
                do {
                    let data = try Data(contentsOf: pdfUrl)
                    webView.load(data, mimeType: "application/pdf", characterEncodingName:"", baseURL: pdfUrl.deletingLastPathComponent())
                    print("pdf file loading...")
                }
                catch {
                    print("failed to open pdf")
                }
                return
            }
        }else{
            print("Pdf URL not fetch")
        }
    }
    
    func setupViews() {
        
        view.addSubview(webView)
        
        // setup AutoLayout...
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        webView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        webView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        webView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
}


